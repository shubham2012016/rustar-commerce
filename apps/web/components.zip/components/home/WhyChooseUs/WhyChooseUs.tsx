import { Sparkles } from "lucide-react"

import FeatureCard from "./FeatureCard"
import { features } from "./whyChooseUs.data"

export default function WhyChooseUs() {
  return (
    <section className="relative overflow-hidden py-24">
      {/* Background */}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-slate-50 via-white to-slate-50" />

      <div className="absolute top-20 -left-20 -z-10 h-72 w-72 rounded-full bg-blue-100/40 blur-3xl" />

      <div className="absolute -right-20 bottom-10 -z-10 h-72 w-72 rounded-full bg-cyan-100/40 blur-3xl" />

      <div className="mx-auto max-w-7xl px-6">
        {/* Header */}
        <div className="mx-auto mb-16 max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-blue-100 bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700">
            <Sparkles size={16} />
            Why Rustar Chem
          </div>

          <h2 className="mt-6 text-4xl font-black tracking-tight text-slate-900 md:text-5xl">
            Trusted by
            <span className="block bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
              Professionals Across India
            </span>
          </h2>

          <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-600">
            Every Rustar Chem product is engineered to deliver reliable
            performance, long-lasting protection, and professional-grade results
            for cars and bikes.
          </p>
        </div>

        {/* Features */}
        <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-4">
          {features.map((feature) => (
            <FeatureCard key={feature.id} feature={feature} />
          ))}
        </div>

        {/* Stats */}
        <div className="mt-20 grid gap-6 rounded-[32px] border border-slate-200 bg-white p-8 shadow-sm md:grid-cols-2 xl:grid-cols-4">
          {[
            {
              value: "5000+",
              label: "Happy Customers",
            },
            {
              value: "50+",
              label: "Products",
            },
            {
              value: "4.8★",
              label: "Average Rating",
            },
            {
              value: "100%",
              label: "Quality Tested",
            },
          ].map((item) => (
            <div key={item.label} className="text-center">
              <h3 className="text-5xl font-black text-blue-600">
                {item.value}
              </h3>

              <p className="mt-2 text-slate-600">{item.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
